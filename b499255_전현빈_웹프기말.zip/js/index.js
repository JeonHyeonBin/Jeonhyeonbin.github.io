$(document).ready(function() {

    var flag = true;

    $(window).scroll(function(){
        var header = $('.header'),
            scroll = $(window).scrollTop();
        var logo = $('#logoImg');
        var nav = $('.navmenu');

        var delaySpeed = 100;
        var fadeSpeed = 1000;

        var scrollPositionWHY = $(".intro_why").offset().top - $('.header').height()-parseInt($(".intro_why").css('margin-top'))-parseInt($(".intro_why").css('padding-top'));
        //console.log(scrollPositionWHY);

        if(scroll > scrollPositionWHY && flag){
            $('ul.textlist li').each(function(i){
                $(this).delay(i*(delaySpeed)).css({opacity:'0'}).animate({opacity:'1'},fadeSpeed);
            });

            flag = false;
        }

        if (scroll > 0) {
            header.addClass('fixed');
            logo.attr('src', 'images/logoScroll.png');
            nav.css('color', '#000000');
        }
        else {
            header.removeClass('fixed');
            logo.attr('src', 'images/logo.png');
            nav.css('color', '#ffffff');
        }
    });

    function cursorsettingList() {
        $('ul.linklist li a img').each(function (i) {
            if ($(this).attr('src') === 'images/defaultView.png') {
                $(this).mouseover(function () {
                    $(this).css('cursor', 'default');
                });
            }
            else {
                $(this).css('cursor', 'pointer');
            }
        });
    }

    function cursorsetting() {
        $('ul.bestlinklist li a img').each(function (i) {
            if ($(this).attr('src') === 'images/defaultBestView.png') {
                $(this).mouseover(function () {
                    $(this).css('cursor', 'default');
                });
            }
            else {
                $(this).css('cursor', 'pointer');
            }
        });
    }


    var selectBtn = $('.selectBtn');

    function defaultView(target, source, returnsource){
        target.mouseover(function(){
            target.attr('src', source);
        }).mouseout(function(){
            target.attr('src', returnsource);
        });
    }

    function onhover() {
        if ($('#imgbtn1').attr('src') === 'images/btn1_active.png') {
            console.log("??");
            $('ul.linklist li a img').each(function (i) {
                $(this).unbind('mouseover');
                $(this).unbind('mouseout');

                var getimgid = $(this).attr('id');

                switch (getimgid) {
                    case 'list1':
                        defaultView($(this), 'images/list1_active.png', 'images/list1.png');
                        break;
                    case 'list2':
                        defaultView($(this), 'images/list2_active.png', 'images/list2.png');
                        break;
                    case 'list3':
                        defaultView($(this), 'images/list3_active.png', 'images/list3.png');
                        break;
                    case 'list4':
                        defaultView($(this), 'images/list4_active.png', 'images/list4.png');
                        break;
                    case 'list5':
                        defaultView($(this), 'images/list5_active.png', 'images/list5.png');
                        break;
                    case 'list6':
                        defaultView($(this), 'images/list6_active.png', 'images/list6.png');
                        break;
                    case 'list7':
                        defaultView($(this), 'images/list7_active.png', 'images/list7.png');
                        break;
                    default:
                        $(this).css('cursor', 'default');
                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');
                }
            });
            return;
        }
        else if ($('#imgbtn2').attr('src') === 'images/btn2_active.png') {
            console.log("??2");
            $('ul.linklist li a img').each(function (i) {
                $(this).unbind('mouseover');
                $(this).unbind('mouseout');

                var getimgid = $(this).attr('id');

                switch (getimgid) {
                    case 'list1':
                        defaultView($(this), 'images/list1_active.png', 'images/list1.png');
                        break;
                    case 'list2':
                        defaultView($(this), 'images/list2_active.png', 'images/list2.png');
                        break;
                    case 'list3':
                        defaultView($(this), 'images/list3_active.png', 'images/list3.png');
                        break;
                    case 'list4':
                        defaultView($(this), 'images/list4_active.png', 'images/list4.png');
                        break;
                    case 'list5':
                        defaultView($(this), 'images/list5_active.png', 'images/list5.png');
                        break;
                    case 'list6':
                        defaultView($(this), 'images/list8_active.png', 'images/list8.png');
                        break;
                    case 'list7':
                        defaultView($(this), 'images/list7_active.png', 'images/list7.png');
                        break;
                    default:
                        $(this).css('cursor', 'default');
                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');
                }
            });
            return;
        }
        else if ($('#imgbtn3').attr('src') === 'images/btn3_active.png') {
            console.log("??3");
            $('ul.linklist li a img').each(function (i) {
                $(this).unbind('mouseover');
                $(this).unbind('mouseout');

                var getimgid = $(this).attr('id');

                switch (getimgid) {
                    case 'list1':
                        defaultView($(this), 'images/list9_active.png', 'images/list9.png');
                        break;
                    case 'list2':
                        defaultView($(this), 'images/list10_active.png', 'images/list10.png');
                        break;
                    case 'list3':
                        defaultView($(this), 'images/list7_active.png', 'images/list7.png');
                        break;
                    default:
                        $(this).css('cursor', 'default');
                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');

                }
            });
            return;
        }
        else if ($('#imgbtn4').attr('src') === 'images/btn4_active.png') {
            console.log("??4");
            $('ul.linklist li a img').each(function (i) {

                $(this).unbind('mouseover');
                $(this).unbind('mouseout');

                var getimgid = $(this).attr('id');

                switch (getimgid) {
                    case 'list1':
                        defaultView($(this), 'images/list5_active.png', 'images/list5.png');
                        break;
                    case 'list2':
                        defaultView($(this), 'images/list11_active.png', 'images/list11.png');
                        break;
                    case 'list3':
                        defaultView($(this), 'images/list9_active.png', 'images/list9.png');
                        break;
                    case 'list4':
                        defaultView($(this), 'images/list4_active.png', 'images/list4.png');
                        break;
                    case 'list5':
                        defaultView($(this), 'images/list6_active.png', 'images/list6.png');
                        break;
                    case 'list6':
                        defaultView($(this), 'images/list12_active.png', 'images/list12.png');
                        break;
                    case 'list7':
                        defaultView($(this), 'images/list13_active.png', 'images/list13.png');
                        break;
                    case 'list8':
                        defaultView($(this), 'images/list14_active.png', 'images/list14.png');
                        break;
                    default:
                        $(this).css('cursor', 'default');
                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');
                }
            });
            return;
        }
        else if ($('#imgbtn5').attr('src') === 'images/btn5_active.png') {
            console.log("??5");
            $('ul.linklist li a img').each(function (i) {

                $(this).unbind('mouseover');
                $(this).unbind('mouseout');

                var getimgid = $(this).attr('id');

                switch (getimgid) {
                    case 'list1':
                        defaultView($(this), 'images/list5_active.png', 'images/list5.png');
                        break;
                    case 'list2':
                        defaultView($(this), 'images/list11_active.png', 'images/list11.png');
                        break;
                    case 'list3':
                        defaultView($(this), 'images/list15_active.png', 'images/list15.png');
                        break;
                    case 'list4':
                        defaultView($(this), 'images/list4_active.png', 'images/list4.png');
                        break;
                    case 'list5':
                        defaultView($(this), 'images/list6_active.png', 'images/list6.png');
                        break;
                    case 'list6':
                        defaultView($(this), 'images/list12_active.png', 'images/list12.png');
                        break;
                    case 'list7':
                        defaultView($(this), 'images/list13_active.png', 'images/list13.png');
                        break;
                    case 'list8':
                        defaultView($(this), 'images/list14_active.png', 'images/list14.png');
                        break;
                    case 'list9':
                        defaultView($(this), 'images/list9_active.png', 'images/list9.png');
                        break;
                    default:
                        $(this).css('cursor', 'default');
                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');
                }
            });
            return;
        }
    }

    onhover();
    cursorsettingList();

    $('.listImg').on('click', function(){
        var getsrc = $(this).attr('src');

        switch (getsrc){
            case 'images/list1_active.png': location.href = 'https://www.invisionapp.com/';
                break;
            case 'images/list2_active.png': location.href = 'https://marvelapp.com/features/prototyping/';
                break;
            case 'images/list3_active.png': location.href = 'https://www.adobe.com/kr/products/xd.html';
                break;
            case 'images/list4_active.png': location.href = 'https://www.flinto.com/';
                break;
            case 'images/list5_active.png': location.href = 'http://principleformac.com/';
                break;
            case 'images/list6_active.png': location.href = 'https://origami.design/';
                break;
            case 'images/list7_active.png': location.href = 'https://www.uxpin.com/';
                break;
            case 'images/list8_active.png': location.href = 'https://www.apple.com/kr/keynote/';
                break;
            case 'images/list9_active.png': location.href = 'https://ko.khanacademy.org/computing/computer-programming/html-css-js';
                break;
            case 'images/list10_active.png': location.href = 'https://azure.microsoft.com/ko-kr/free/search/?&OCID=AID631159_SEM_RMa1ttGw&gclid=EAIaIQobChMIhMCQrufd2wIVkoBwCh05AQ0_EAAYASAAEgJnNfD_BwE&dclid=CK7eo7Pn3dsCFYqclgodiB4Asw';
                break;
            case 'images/list11_active.png': location.href = 'https://www.adobe.com/kr/products/aftereffects.html';
                break;
            case 'images/list12_active.png': location.href = 'https://framer.com/';
                break;
            case 'images/list13_active.png': location.href = 'https://developer.apple.com/kr/xcode/';
                break;
            case 'images/list14_active.png': location.href = 'https://blog.phonegap.com/';
                break;
            case 'images/list15_active.png': location.href = 'https://proto.io/';
                break;
        }
    });

    $('.bestimg').on('click', function(){
        var getsrc = $(this).attr('src');

        switch (getsrc){
            case 'images/best1_active.png': location.href = 'https://www.adobe.com/kr/products/aftereffects.html';
                break;
            case 'images/best2_active.png': location.href = 'https://www.apple.com/kr/keynote/';
                break;
            case 'images/best3_active.png': location.href = 'https://www.uxpin.com/';
                break;
            case 'images/best4_active.png': location.href = 'https://www.lucidchart.com/';
                break;
            case 'images/best5_active.png': location.href = 'https://balsamiq.com/';
                break;
            case 'images/best6_active.png': location.href = 'https://www.invisionapp.com/';
                break;
            case 'images/best7_active.png': location.href = 'https://marvelapp.com/features/prototyping/';
                break;
            case 'images/best8_active.png': location.href = 'https://www.axure.com/';
                break;
            case 'images/best9_active.png': location.href = 'https://www.adobe.com/kr/products/xd.html';
                break;
            case 'images/best10_active.png': location.href = 'https://atomic.io/';
                break;
            case 'images/best11_active.png': location.href = 'https://ko.khanacademy.org/computing/computer-programming/html-css-js';
                break;
            case 'images/best12_active.png': location.href = 'https://framer.com/';
                break;
            case 'images/best13_active.png': location.href = 'http://webframeworks.kr/getstarted/ionic/';
                break;
            case 'images/best14_active.png': location.href = 'https://www.flinto.com/ ';
                break;
            case 'images/best15_active.png': location.href = 'https://proto.io/';
                break;
            case 'images/best16_active.png': location.href = 'https://origami.design/';
                break;
            case 'images/best17_active.png': location.href = 'http://principleformac.com/';
                break;
        }
    });

    selectBtn.on('click', function () {

        var getid = $(this).attr('id');
        var delaySpeed = 100;
        var fadeSpeed = 1000;

        switch (getid){
            case 'btn1':
                $('#imgbtn1').attr('src', 'images/btn1_active.png');
                $('#imgbtn2').attr('src', 'images/btn2.png');
                $('#imgbtn3').attr('src', 'images/btn3.png');
                $('#imgbtn4').attr('src', 'images/btn4.png');
                $('#imgbtn5').attr('src', 'images/btn5.png');

                $('#list1').attr('src', 'images/list1.png');
                $('#list2').attr('src', 'images/list2.png');
                $('#list3').attr('src', 'images/list3.png');
                $('#list4').attr('src', 'images/list4.png');
                $('#list5').attr('src', 'images/list5.png');
                $('#list6').attr('src', 'images/list6.png');
                $('#list7').attr('src', 'images/list7.png');
                $('#list8').attr('src', 'images/defaultView.png');
                $('#list9').attr('src', 'images/defaultView.png');
                $('#list10').attr('src', 'images/defaultView.png');

                onhover();


                $('ul.linklist li').each(function(i){
                    $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                });
                cursorsettingList();
                break;
            case 'btn2':
                $('#imgbtn1').attr('src', 'images/btn1.png');
                $('#imgbtn2').attr('src', 'images/btn2_active.png');
                $('#imgbtn3').attr('src', 'images/btn3.png');
                $('#imgbtn4').attr('src', 'images/btn4.png');
                $('#imgbtn5').attr('src', 'images/btn5.png');

                $('#list1').attr('src', 'images/list1.png');
                $('#list2').attr('src', 'images/list2.png');
                $('#list3').attr('src', 'images/list3.png');
                $('#list4').attr('src', 'images/list4.png');
                $('#list5').attr('src', 'images/list5.png');
                $('#list6').attr('src', 'images/list8.png');
                $('#list7').attr('src', 'images/list7.png');
                $('#list8').attr('src', 'images/defaultView.png');
                $('#list9').attr('src', 'images/defaultView.png');
                $('#list10').attr('src', 'images/defaultView.png');

                onhover();

                $('ul.linklist li').each(function(i){
                    $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                });
                cursorsettingList();
                break;
            case 'btn3':
                $('#imgbtn1').attr('src', 'images/btn1.png');
                $('#imgbtn2').attr('src', 'images/btn2.png');
                $('#imgbtn3').attr('src', 'images/btn3_active.png');
                $('#imgbtn4').attr('src', 'images/btn4.png');
                $('#imgbtn5').attr('src', 'images/btn5.png');

                $('#list1').attr('src', 'images/list9.png');
                $('#list2').attr('src', 'images/list10.png');
                $('#list3').attr('src', 'images/list7.png');
                $('#list4').attr('src', 'images/defaultView.png');
                $('#list5').attr('src', 'images/defaultView.png');
                $('#list6').attr('src', 'images/defaultView.png');
                $('#list7').attr('src', 'images/defaultView.png');
                $('#list8').attr('src', 'images/defaultView.png');
                $('#list9').attr('src', 'images/defaultView.png');
                $('#list10').attr('src', 'images/defaultView.png');

                onhover();

                $('ul.linklist li').each(function(i){
                    $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                });
                cursorsettingList();
                break;
            case 'btn4':
                $('#imgbtn1').attr('src', 'images/btn1.png');
                $('#imgbtn2').attr('src', 'images/btn2.png');
                $('#imgbtn3').attr('src', 'images/btn3.png');
                $('#imgbtn4').attr('src', 'images/btn4_active.png');
                $('#imgbtn5').attr('src', 'images/btn5.png');

                $('#list1').attr('src', 'images/list5.png');
                $('#list2').attr('src', 'images/list11.png');
                $('#list3').attr('src', 'images/list9.png');
                $('#list4').attr('src', 'images/list4.png');
                $('#list5').attr('src', 'images/list6.png');
                $('#list6').attr('src', 'images/list12.png');
                $('#list7').attr('src', 'images/list13.png');
                $('#list8').attr('src', 'images/list14.png');
                $('#list9').attr('src', 'images/defaultView.png');
                $('#list10').attr('src', 'images/defaultView.png');

                onhover();

                $('ul.linklist li').each(function(i){
                    $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                });
                cursorsettingList();
                break;
            case 'btn5':
                $('#imgbtn1').attr('src', 'images/btn1.png');
                $('#imgbtn2').attr('src', 'images/btn2.png');
                $('#imgbtn3').attr('src', 'images/btn3.png');
                $('#imgbtn4').attr('src', 'images/btn4.png');
                $('#imgbtn5').attr('src', 'images/btn5_active.png');

                $('#list1').attr('src', 'images/list5.png');
                $('#list2').attr('src', 'images/list11.png');
                $('#list3').attr('src', 'images/list15.png');
                $('#list4').attr('src', 'images/list4.png');
                $('#list5').attr('src', 'images/list6.png');
                $('#list6').attr('src', 'images/list12.png');
                $('#list7').attr('src', 'images/list13.png');
                $('#list8').attr('src', 'images/list14.png');
                $('#list9').attr('src', 'images/list9.png');
                $('#list10').attr('src', 'images/defaultView.png');

                onhover();


                $('ul.linklist li').each(function(i){
                    $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                });
                cursorsettingList();
                break;
        }
    });

    var result="";

    $('.choosebtn').on('click', function(){

        var delaySpeed = 100;
        var fadeSpeed = 1000;

        var scrollPosition = $(".titleArea").offset().top-140;
        //console.log(scrollPosition);

        if($(this).text() === 'NO'){
            if($('p.question').text() === 'Are you usability testing?'){
                $('#best1').attr('src', 'images/best1.png');
                $('#best2').attr('src', 'images/best2.png');

                $("html, body").animate({
                    scrollTop: scrollPosition
                }, 500);

                $('ul.bestlinklist li').each(function(i){
                    if($('ul.bestlinklist li a img').attr('src') === 'images/defaultBestView.png'){
                        return false;
                    }
                    $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                });

                $('ul.bestlinklist li a img').each(function (i) {

                    $(this).unbind('mouseover');
                    $(this).unbind('mouseout');

                    var getimgid = $(this).attr('id');

                    switch (getimgid) {
                        case 'best1':
                            defaultView($(this), 'images/best1_active.png', 'images/best1.png');
                            break;
                        case 'best2':
                            defaultView($(this), 'images/best2_active.png', 'images/best2.png');
                            break;
                        default:
                            $(this).css('cursor', 'default');
                            $(this).unbind('mouseover');
                            $(this).unbind('mouseout');
                    }
                });

                cursorsetting();

            }
            else if($('p.question').text() === 'Need screen transitions?'){
                result = '0';
                $('p.question').text('Need Sketch Import?');
            }
            else if($('p.question').text() === 'Need Sketch Import?'){
                result+='0';
                $('p.question').text('Need micro interactions?');
            }
            else if($('p.question').text() === 'Need micro interactions?'){
                if(result === '00'){
                    $('#best1').attr('src', 'images/best4.png');
                    $('#best2').attr('src', 'images/best5.png');

                    $("html, body").animate({
                        scrollTop: scrollPosition
                    }, 500);

                    $('ul.bestlinklist li').each(function(i){
                        if($('ul.bestlinklist li a img').attr('src') === 'images/defaultBestView.png'){
                            return false;
                        }
                        $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                    });

                    $('ul.bestlinklist li a img').each(function (i) {

                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');

                        var getimgid = $(this).attr('id');

                        switch (getimgid) {
                            case 'best1':
                                defaultView($(this), 'images/best4_active.png', 'images/best4.png');
                                break;
                            case 'best2':
                                defaultView($(this), 'images/best5_active.png', 'images/best5.png');
                                break;
                            default:
                                $(this).css('cursor', 'default');
                                $(this).unbind('mouseover');
                                $(this).unbind('mouseout');
                        }
                    });

                    cursorsetting();
                }
                else if(result === '11'){
                    $('#best1').attr('src', 'images/best6.png');
                    $('#best2').attr('src', 'images/best7.png');

                    $("html, body").animate({
                        scrollTop: scrollPosition
                    }, 500);

                    $('ul.bestlinklist li').each(function(i){
                        if($('ul.bestlinklist li a img').attr('src') === 'images/defaultBestView.png'){
                            return false;
                        }
                        $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                    });

                    $('ul.bestlinklist li a img').each(function (i) {

                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');

                        var getimgid = $(this).attr('id');

                        switch (getimgid) {
                            case 'best1':
                                defaultView($(this), 'images/best6_active.png', 'images/best6.png');
                                break;
                            case 'best2':
                                defaultView($(this), 'images/best7_active.png', 'images/best7.png');
                                break;
                            default:
                                $(this).css('cursor', 'default');
                                $(this).unbind('mouseover');
                                $(this).unbind('mouseout');
                        }
                    });

                    cursorsetting();
                }
            }
            else if($('p.question').text() === 'Need user input?(Code)'){
                $('#best1').attr('src', 'images/best14.png');
                $('#best2').attr('src', 'images/best15.png');
                $('#best3').attr('src', 'images/best16.png');
                $('#best4').attr('src', 'images/best17.png');

                $("html, body").animate({
                    scrollTop: scrollPosition
                }, 500);

                $('ul.bestlinklist li').each(function(i){
                    if($('ul.bestlinklist li a img').attr('src') === 'images/defaultBestView.png'){
                        return false;
                    }
                    $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                });

                $('ul.bestlinklist li a img').each(function (i) {

                    $(this).unbind('mouseover');
                    $(this).unbind('mouseout');

                    var getimgid = $(this).attr('id');

                    switch (getimgid) {
                        case 'best1':
                            defaultView($(this), 'images/best14_active.png', 'images/best14.png');
                            break;
                        case 'best2':
                            defaultView($(this), 'images/best15_active.png', 'images/best15.png');
                            break;
                        case 'best3':
                            defaultView($(this), 'images/best16_active.png', 'images/best16.png');
                            break;
                        case 'best4':
                            defaultView($(this), 'images/best17_active.png', 'images/best17.png');
                            break;
                        default:
                            $(this).css('cursor', 'default');
                            $(this).unbind('mouseover');
                            $(this).unbind('mouseout');
                    }
                });

                cursorsetting();
            }
        }
        else if($(this).text() === 'YES'){
            if($('p.question').text() === 'Are you usability testing?') {
                $('p.question').text('Need screen transitions?');
            }
            else if($('p.question').text() === 'Need screen transitions?'){
                result = '1';
                $('p.question').text('Need Sketch Import?');
            }
            else if($('p.question').text() === 'Need Sketch Import?'){
                if(result === '0'){
                    $('#best1').attr('src', 'images/best3.png');

                    $("html, body").animate({
                        scrollTop: scrollPosition
                    }, 500);

                    $('ul.bestlinklist li').each(function(i){
                        if($('ul.bestlinklist li a img').attr('src') === 'images/defaultBestView.png'){
                            return false;
                        }
                        $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                    });

                    $('ul.bestlinklist li a img').each(function (i) {

                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');

                        var getimgid = $(this).attr('id');

                        switch (getimgid) {
                            case 'best1':
                                defaultView($(this), 'images/best3_active.png', 'images/best3.png');
                                break;
                            default:
                                $(this).css('cursor', 'default');
                                $(this).unbind('mouseover');
                                $(this).unbind('mouseout');
                        }
                    });

                    cursorsetting();
                }
                else {
                    result += '1';
                    $('p.question').text('Need micro interactions?');
                }
            }
            else if($('p.question').text() === 'Need micro interactions?'){
                if(result == '00'){
                    $('#best1').attr('src', 'images/best3.png');

                    $("html, body").animate({
                        scrollTop: scrollPosition
                    }, 500);

                    $('ul.bestlinklist li').each(function(i){
                        if($('ul.bestlinklist li a img').attr('src') === 'images/defaultBestView.png'){
                            return false;
                        }
                        $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                    });

                    $('ul.bestlinklist li a img').each(function (i) {

                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');

                        var getimgid = $(this).attr('id');

                        switch (getimgid) {
                            case 'best1':
                                defaultView($(this), 'images/best3_active.png', 'images/best3.png');
                                break;
                            default:
                                $(this).css('cursor', 'default');
                                $(this).unbind('mouseover');
                                $(this).unbind('mouseout');
                        }
                    });

                    cursorsetting();
                }
                else if(result == '10'){
                    $('#best1').attr('src', 'images/best8.png');
                    $('#best2').attr('src', 'images/best9.png');
                    $('#best3').attr('src', 'images/best10.png');

                    $("html, body").animate({
                        scrollTop: scrollPosition
                    }, 500);

                    $('ul.bestlinklist li').each(function(i){
                        if($('ul.bestlinklist li a img').attr('src') === 'images/defaultBestView.png'){
                            return false;
                        }
                        $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                    });

                    $('ul.bestlinklist li a img').each(function (i) {

                        $(this).unbind('mouseover');
                        $(this).unbind('mouseout');

                        var getimgid = $(this).attr('id');

                        switch (getimgid) {
                            case 'best1':
                                defaultView($(this), 'images/best8_active.png', 'images/best8.png');
                                break;
                            case 'best2':
                                defaultView($(this), 'images/best9_active.png', 'images/best9.png');
                                break;
                            case 'best3':
                                defaultView($(this), 'images/best10_active.png', 'images/best10.png');
                                break;
                            default:
                                $(this).css('cursor', 'default');
                                $(this).unbind('mouseover');
                                $(this).unbind('mouseout');
                        }
                    });

                    cursorsetting();
                }
                else if(result === '11'){
                    result += '1'
                    $('p.question').text('Need user input?(Code)');
                }
            }
            else if($('p.question').text() === 'Need user input?(Code)'){
                $('#best1').attr('src', 'images/best11.png');
                $('#best2').attr('src', 'images/best12.png');
                $('#best3').attr('src', 'images/best13.png');

                $("html, body").animate({
                    scrollTop: scrollPosition
                }, 500);

                $('ul.bestlinklist li').each(function(i){
                    if($('ul.bestlinklist li a img').attr('src') === 'images/defaultBestView.png'){
                        return false;
                    }
                    $(this).delay(i*(delaySpeed)).css({display:'inline-block',opacity:'0'}).animate({opacity:'1'},fadeSpeed);
                });

                $('ul.bestlinklist li a img').each(function (i) {

                    $(this).unbind('mouseover');
                    $(this).unbind('mouseout');

                    var getimgid = $(this).attr('id');

                    switch (getimgid) {
                        case 'best1':
                            defaultView($(this), 'images/best11_active.png', 'images/best11.png');
                            break;
                        case 'best2':
                            defaultView($(this), 'images/best12_active.png', 'images/best12.png');
                            break;
                        case 'best3':
                            defaultView($(this), 'images/best13_active.png', 'images/best13.png');
                            break;
                        default:
                            $(this).css('cursor', 'default');
                            $(this).unbind('mouseover');
                            $(this).unbind('mouseout');
                    }
                });

                cursorsetting();
            }
        }
    });

    $('.navmenu').on('click', function(){
        var getid = $(this).attr('id');
        var scrollPosition1 = $(".intro_what").offset().top- $('.header').height()+1;
        var scrollPosition2 = $(".intro_why").offset().top - $('.header').height();
        var scrollPosition3 = $(".selectionArea").offset().top - $('.header').height();
        var scrollPosition4 = $(".customizeArea").offset().top- $('.header').height();

        switch (getid) {
            case 'nav1':
                $("html, body").animate({
                    scrollTop: scrollPosition1
                }, 500);
                break;
            case 'nav2':
                $("html, body").animate({
                    scrollTop: scrollPosition2
                }, 500);
                break;
            case 'nav3':
                $("html, body").animate({
                    scrollTop: scrollPosition3
                }, 500);
                break;
            case 'nav4':
                $("html, body").animate({
                    scrollTop: scrollPosition4
                }, 500);
                break;
        }
    });

    $('.logo').on('click', function(){

        $("html, body").animate({
            scrollTop: 0
        }, 500);
    });
});